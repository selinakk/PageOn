### 김시윤
- member 테이블에 id가 tester2인 데이터 존재
- work 테이블에 num이 123인 데이터 존재
- comment컨트롤러 매개변수 모듈마다 설정
- application.properties에서 db 비밀번호 수정

### 홍석표
- applcation.properties에서 file.dir을 본인 PC 경로에 맞게 수정