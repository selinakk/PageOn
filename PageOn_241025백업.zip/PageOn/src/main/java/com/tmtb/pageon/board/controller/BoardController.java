package com.tmtb.pageon.board.controller;


import com.tmtb.pageon.board.service.BoardService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Slf4j
@Controller
    public class BoardController {

    @Autowired
    BoardService service;




}