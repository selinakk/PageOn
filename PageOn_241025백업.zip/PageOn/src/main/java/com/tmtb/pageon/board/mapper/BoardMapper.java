package com.tmtb.pageon.board.mapper;

import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface BoardMapper {


}
