package com.tmtb.pageon.community.model;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import java.sql.Timestamp;

@Data
public class CommunityVO {




}