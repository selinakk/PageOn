package com.tmtb.pageon.login.model;


import lombok.Data;

@Data
public class LoginVO {

    private int num;

    private String id;

    private String pw;



}
