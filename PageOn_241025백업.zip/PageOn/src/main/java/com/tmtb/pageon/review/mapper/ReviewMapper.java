package com.tmtb.pageon.review.mapper;

import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface ReviewMapper {


}
