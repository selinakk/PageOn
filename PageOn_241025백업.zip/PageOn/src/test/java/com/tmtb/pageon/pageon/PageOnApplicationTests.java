package com.tmtb.pageon.pageon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PageOnApplicationTests {

    @Test
    void contextLoads() {
    }

}
