import os
import re
import json
import random
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.common.exceptions import StaleElementReferenceException, NoSuchElementException

# 카테고리별 URL 목록 (판타지만 남김)
categories = {
    "판타지": "https://page.kakao.com/menu/10011/screen/91",
    "현대판타지": "https://page.kakao.com/menu/10011/screen/64",
    "무협": "https://page.kakao.com/menu/10011/screen/70",
    "드라마": "https://page.kakao.com/menu/10011/screen/100",
    "로판": "https://page.kakao.com/menu/10011/screen/92",
    "로맨스": "https://page.kakao.com/menu/10011/screen/68",
}

# Selenium 드라이버 설정
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))

try:
    all_novels_data = {}

    # 각 카테고리의 작품 페이지 링크 추출 및 정보 수집
    for category, url in categories.items():
        print(f"Processing category: {category}")
        driver.get(url)
        time.sleep(random.uniform(2, 5))  # 페이지 로드 대기(랜덤 시간)

        # 카테고리별 최대 50개만 수집하기 위해 초기화
        category_data = []

        # 상위 50개 링크로 접근하여 정보 수집
        for i in range(50):
            try:
                # 요소 다시 찾기
                elements = driver.find_elements(By.XPATH, '//*[@id="__next"]/div/div[2]/div/div[2]/div[5]/div/div[2]/div/div/div/div/div/a')
                if i >= len(elements):
                    break

                element = elements[i]
                work_url = element.get_attribute('href')  # 작품 원래 링크
                work_url_about = work_url + "?tab_type=about"
                print(f"{category} - 작품 페이지: {work_url_about}")

                # 작품 페이지로 이동하여 정보 수집
                driver.get(work_url_about)
                time.sleep(random.uniform(2, 5))  # 작품 페이지 로드 대기(랜덤 시간)

                # 연령 확인 메시지가 있는지 확인
                try:
                    age_check_element = driver.find_element(By.XPATH, '//*[@id="__next"]/div/div[2]/div/div/div/div[2]/div')
                    if "서비스 이용을 위해 연령 확인이 필요 합니다." in age_check_element.text:
                        print("연령 확인이 필요한 작품입니다. 다음 작품으로 이동합니다.")
                        continue  # 다음 작품으로 이동
                except NoSuchElementException:
                    pass

                # 이미지 URL, 제목, 작가, 줄거리, 공급자 정보 수집
                image_url, title, author, summary, supplier, age_rating = None, "정보 없음", "정보 없음", "정보 없음", "정보 없음", "정보 없음"

                # 이미지 URL 수집
                try:
                    image_element = driver.find_element(By.XPATH, '//*[@class="absolute top-0 left-0 h-full w-full object-cover object-center blur-[12px]"]')
                    image_url = image_element.get_attribute('src') if image_element else None
                except NoSuchElementException:
                    pass

                # 제목, 작가 정보 수집
                try:
                    title = driver.find_element(By.CLASS_NAME, 'font-large3-bold').text
                    author = driver.find_element(By.XPATH, '//*[@id="__next"]/div/div[2]/div[1]/div[1]/div[1]/div/div[2]/a/div/span[2]').text
                except NoSuchElementException:
                    pass

                # 줄거리 및 공급자 정제
                try:
                    raw_summary = driver.find_element(By.XPATH, '//*[@id="__next"]/div/div[2]/div[1]/div[2]/div[2]/div/div/div[1]/div/div[2]/div/div/span').text
                    summary = re.sub(r'[\n]+', ' ', raw_summary)  # 줄 바꿈 제거
                except NoSuchElementException:
                    pass

                try:
                    raw_supplier = driver.find_element(By.XPATH, '//*[@id="__next"]/div/div[2]/div[1]/div[2]/div[2]/div/div/div[4]/div[2]/div/div[3]').text
                    supplier = re.sub(r'발행자\s*|\n', '', raw_supplier)  # '발행자'와 줄 바꿈 제거
                except NoSuchElementException:
                    pass

                # 연령 등급 수집
                try:
                    age_rating = driver.find_element(By.XPATH, '//*[@id="__next"]/div/div[2]/div[1]/div[2]/div[2]/div/div/div[4]/div[2]/div/div[4]/span[2]').text
                except NoSuchElementException:
                    pass

                # 데이터 저장
                novel_data = {
                    "category": category,
                    "title": title,
                    "author": author,
                    "summary": summary,
                    "supplier": supplier,
                    "age_rating": age_rating,
                    "image_url": image_url,
                    "work_url": work_url
                }
                category_data.append(novel_data)

                # 카테고리 목록 페이지로 돌아가기
                driver.back()
                time.sleep(random.uniform(2, 5))  # 페이지 로드 대기(랜덤 시간)

            except (StaleElementReferenceException, NoSuchElementException) as e:
                print(f"오류 발생: {e}")

        # 카테고리별로 수집한 데이터 저장
        all_novels_data[category] = category_data
        print(f"{category} 카테고리에서 {len(category_data)}개의 작품을 수집했습니다.")

    # 저장할 디렉토리 생성
    os.makedirs("D:/Multi26/webnovel/data", exist_ok=True)

    # JSON 파일로 저장
    with open("D:/Multi26/webnovel/data/novels_data.json", "w", encoding="utf-8") as f:
        json.dump(all_novels_data, f, ensure_ascii=False, indent=4)

    print("모든 카테고리 데이터가 D:/Multi26/webnovel/data/novels_data.json에 저장되었습니다.")

finally:
    driver.quit()
